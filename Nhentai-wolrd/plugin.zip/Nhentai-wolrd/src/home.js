function execute() {
    return Response.success([
        {title: "Cập nhật", input: "https://nhentaiworld-h1.info/", script: "gen.js"},
    ]);
}